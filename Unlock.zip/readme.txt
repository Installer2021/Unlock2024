Password: gamefreecheat2024


Installation Instructions:

1. Disable your antivirus software and Windows Defender before starting the installation. This is necessary because some security software may detect the cheat as a false positive and block its installation.

2. Run injector.exe.
3. Select main.exe to load into the game.
4. Configure the settings in config.ini.
5. Enjoy the game!

Additional Information:

- main.exe: the main executable file of the reader. Modifies the game memory to provide advantages. Includes a GUI for customizing chit settings.
- config.ini: configuration file for customizing the reader settings.
- libexample.dll: a library necessary for the reader to work.
- injector.exe: program for loading the reader into the game memory.
- obfuscator.exe: a tool for obfuscating the code of the reader to protect it from detection by anti-readers.

Translated with DeepL.com (free version)